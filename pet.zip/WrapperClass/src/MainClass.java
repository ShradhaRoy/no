
public class MainClass {

	public static void main(String[] args) {
		int num1=100;
		Integer iob=num1;
		System.out.println(iob+" shows Auto boxing");
		Integer iob3=num1+iob+iob+200;
		System.out.println(iob3);
		
		if(iob3.equals(500))
		{
			System.out.println("correct");
		}
		else
		{
			System.out.println("think it over");
		}
		
		Integer iob2=200;
		int num=iob2;
		System.out.println(num+" shows auto-unboxing");
		

	}

}
